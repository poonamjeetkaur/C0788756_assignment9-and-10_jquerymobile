$(document).ready(function() {
	//hide all errors, which will only show when called below
	
	$("#mail_err_msg").hide();
	$("#fname_err_msg").hide();
	$("#lname_err_msg").hide();
	$("#pass_err_msg").hide();
	$("#confirm_pass_err_msg").hide();
	$("#birth_err_msg").hide();

	var err_email = false;
	var err_fname = false;
	var err_lname = false;
	var err_password = false;
	var err_confirm_password = false;
	var err_birth = false;
	
	//Excecute when the use click out of the box "focusout"

	$("#mail").focusout(function() {

		mail_check();
		
	});
	
	$("#fname").focusout(function() {

		fname_check();
		
	});
	$("#lname").focusout(function() {

		lname_check();
		
	});
	$("#pass").focusout(function() {

		pass_check();
		
	});
	$("#confirm_password").focusout(function() {

		confirm_pass_check();
		
	});
	$("#birth").focusout(function() {

		birth_check();
		
	});
	
	function fname_check() {
	
		var fname_length = $("#fname").val().length;
		if(fname_length < 5 || fname_length > 20) {
			$("#fname_err_msg").html("Your first name must be between 5-20 characters");
			$("#fname_err_msg").show();
			err_fname = true;
		} else {
			$("#fname_err_msg").hide();
		}
	
	}

	function lname_check() {
	
		var lname_length = $("#lname").val().length;
		if(lname_length < 5 || lname_length > 20) {
			$("#lname_err_msg").html("Your last name must be between 5-20 characters");
			$("#lname_err_msg").show();
			err_lname = true;
		} else {
			$("#lname_err_msg").hide();
		}
	
	}
	
	function pass_check() {
	
		var pass_length = $("#pass").val().length;
		
		if(pass_length < 7) {
			$("#pass_err_msg").html("Your password must be at least 7 characters");
			$("#pass_err_msg").show();
			err_password = true;
		} else {
			$("#pass_err_msg").hide();
		}
	
	}
	
	function confirm_pass_check() {
	
		var pass = $("#pass").val();
		var confirm_password = $("#confirm_password").val();
		
		if(pass !=  confirm_password) {
			$("#confirm_pass_err_msg").html("Your passwords does not match");
			$("#confirm_pass_err_msg").show();
			err_retype_password = true;
		} else {
			$("#confirm_pass_err_msg").hide();
		}
	
	}

	function mail_check() {

		var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
	
		if(pattern.test($("#mail").val())) {
			$("#mail_err_msg").hide();
		} else {
			$("#mail_err_msg").html("Invalid email address");
			$("#mail_err_msg").show();
			err_email = true;
		}
	
	}
	function birth_check(){
		var birth_length = $("#birth").val().length;
		if(birth_length < 3) {
			$("#birth_err_msg").html("Enter Birth date");
			$("#birth_err_msg").show();
			err_birth = true;
		} else {
			$("#birth_err_msg").hide();
		}
	}

	$("#signuppage").submit(function() {
											
		err_email = false;
		err_fname = false;
		err_lname = false;
		err_password = false;
		err_retype_password = false;
		err_birth = false;
										
		mail_check();
		fname_check();
		lname_check();
		pass_check();
		confirm_pass_check();
		birth_check();
		
		if(err_email == false && err_fname == false && err_lname == false && err_password == false && err_retype_password == false && err_birth == false) {
			return true;
		} else {
			return false;	
		}

	});

});