$(document).ready(function() {
	//hide all errors, which will only show when called below
	$("#email_err_msg").hide();
	$("#pass_err_msg").hide();

	var err_mail = false;
	var err_pass = false;
	
	//Excecute when the use click out of the box "focusout"
	$("#mail").focusout(function() {

		mail_check();
		
	});
	
	$("#pass").focusout(function() {

		pass_check();
		
	});

	function pass_check() {
	
		var password_length = $("#pass").val().length;
		console.log(password_length);
		if(password_length < 7) {
			$("#pass_err_msg").html("Entered password must be at least 7 characters");
			$("#pass_err_msg").show();
			err_pass = true;
		} else {
			$("#pass_err_msg").hide();
		}
	
	}

	function mail_check() {

		var pat = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
	
		if(pat.test($("#email").val())) {
			$("#mail_err_msg").hide();
		} else {
			$("#mail_err_msg").html("Invalid email address");
			$("#mail_err_msg").show();
			err_mail = true;
		}
	
	}

	$("#loginpage").submit(function() {
											
		err_mail = false;
		err_pass = false;
		
		mail_check();					
		pass_check();
		
		if(err_pass == false && err_mail == false) {
			return true;
		} else {
			return false;	
		}

	});

});